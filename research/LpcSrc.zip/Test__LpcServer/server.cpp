#include <windows.h>
#include <ntsecapi.h>
#include <AwkLpc.h>
#include <conio.h>
#include <stdio.h>

#define NT_SUCCESS(x) ((x)>=0)

typedef struct _LPC_MESSAGE
{
	LPC_MESSAGE_HEADER      Hdr;
	BYTE                    Data[200];
} LPC_MESSAGE, *PLPC_MESSAGE;

class MyLpcServer : public LpcServer
{
public:
	MyLpcServer()
	{
		m_nClients = 0;
	};

	virtual NTSTATUS OnConnect(LPC_MESSAGE_HEADER* pRequest, BOOL* bAccept, PVOID* pTag)
	{
		NTSTATUS NtStatus = LpcServer::OnConnect(pRequest, bAccept, pTag);
		if(!NT_SUCCESS(NtStatus)) return NtStatus;
		*bAccept = TRUE;

		m_nClients++;
		*pTag = (PVOID)m_nClients;

		printf("Client #%u connected.\n", m_nClients);
		return STATUS_SUCCESS;
	}

	virtual NTSTATUS OnRequest(LpcReplyPort& ReplyPort, LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply)
	{
		NTSTATUS NtStatus = LpcServer::OnRequest(ReplyPort, pRequest, pReply);
		if(!NT_SUCCESS(NtStatus)) return NtStatus;
		memcpy(((LPC_MESSAGE*)pReply)->Data, ((LPC_MESSAGE*)pRequest)->Data, ((LPC_MESSAGE*)pRequest)->Hdr.DataLength);

		PBYTE pInMem = (PBYTE)ReplyPort.GetClientMem().ViewBase;
		PBYTE pOutMem = (PBYTE)ReplyPort.GetOwnMem().ViewBase;
		if(!(pInMem&&pOutMem)) { printf("pInMem==NULL or pOutMem==NULL\n"); return -1; };

		*pOutMem = (*pInMem)*(*pInMem);

		//printf("MESSAGE!\n");
		return STATUS_SUCCESS;
	}

	virtual NTSTATUS OnClose(LpcReplyPort& ReplyPort)
	{
		NTSTATUS NtStatus = LpcServer::OnClose(ReplyPort);
		if(!NT_SUCCESS(NtStatus)) return NtStatus;
		printf("Client #%u disconnected.\n", ReplyPort.GetUserPtr());
		return STATUS_SUCCESS;
	}

	virtual NTSTATUS OnIdle()
	{
		NTSTATUS NtStatus = LpcServer::OnIdle();
		if(!NT_SUCCESS(NtStatus)) return NtStatus;

		printf("Server has been idle for too long - terminating.\n");

		return STATUS_UNSUCCESSFUL;
	}
protected:
	unsigned int m_nClients;
	unsigned int m_nIdle;
};

int main()
{
	NTSTATUS NtStatus;
	MyLpcServer server;
	NtStatus = server.Create(L"\\BaseNamedObjects\\PscSvcPort", TRUE, sizeof(LPC_MESSAGE), 0x1000);
	if(!NT_SUCCESS(NtStatus))
	{
		printf("Create() status=0x%X;\n", NtStatus);
		return -1;
	};

	server.SetTimeout(15000);

	LPC_MESSAGE Msg, Reply;
	NtStatus = server.Run(&Msg.Hdr, &Reply.Hdr);
    
	printf("Server terminated (status=%X). Press any key.\n", NtStatus);
	getch();
	return 0;
}