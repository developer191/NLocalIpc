#include "AwkLpc_i.h"

LpcPort::LpcPort()
{
	m_hPort = NULL;
	m_Tag = NULL;
	m_bWaitable = FALSE;
}

LpcPort::~LpcPort()
{
	Destroy();
}

NTSTATUS LpcPort::Create(LPCWSTR PortName, BOOL bWaitable, DWORD dwMaxMsgSize)
{
	ASSERT(m_hPort==NULL);

	NTSTATUS NtStatus;
	OBJECT_ATTRIBUTES port_attr;
	UNICODE_STRING port_name; RtlInitUnicodeString(&port_name, PortName);

	InitializeObjectAttributes(&port_attr, &port_name, 0, NULL, NULL);
	m_bWaitable = bWaitable;
	if(m_bWaitable)
		NtStatus = NtCreateWaitablePort(&m_hPort, &port_attr, 40, dwMaxMsgSize, NULL);
	else
		NtStatus = NtCreatePort(&m_hPort, &port_attr, 40, dwMaxMsgSize, NULL);
	return NtStatus;
};

NTSTATUS LpcPort::Connect(LPCWSTR PortName, IN OUT PLPC_SECTION_OWNER_MEMORY pClientMem OPTIONAL, OUT PLPC_SECTION_MEMORY pServerMem OPTIONAL)
{
	ASSERT(m_hPort==NULL);
	
	NTSTATUS NtStatus;
	UNICODE_STRING port_name; RtlInitUnicodeString(&port_name, PortName);
	SECURITY_QUALITY_OF_SERVICE SecurityQos = { sizeof(SecurityQos), SecurityImpersonation, SECURITY_DYNAMIC_TRACKING, TRUE };
	NtStatus = NtConnectPort(&m_hPort, &port_name, &SecurityQos, pClientMem, pServerMem, NULL, NULL, NULL);
	return NtStatus;
}

NTSTATUS LpcPort::_Accept(LPC_MESSAGE_HEADER* pMsg, PVOID Tag, BOOL bAccept, IN OUT PLPC_SECTION_OWNER_MEMORY pServerMem OPTIONAL, OUT PLPC_SECTION_MEMORY pClientMem OPTIONAL)
{
	ASSERT(m_hPort==NULL);

	NTSTATUS NtStatus;
	NtStatus = NtAcceptConnectPort(&m_hPort, (PVOID)Tag, pMsg, bAccept, pServerMem, pClientMem);
	if(!NT_SUCCESS(NtStatus)) return NtStatus;

	NtStatus = NtCompleteConnectPort(m_hPort);
	return NtStatus;
};

NTSTATUS LpcPort::Accept(LPC_MESSAGE_HEADER* pMsg, PVOID Tag, IN OUT PLPC_SECTION_OWNER_MEMORY pServerMem OPTIONAL, OUT PLPC_SECTION_MEMORY pClientMem OPTIONAL)
{
	m_Tag = Tag;
	return _Accept(pMsg, Tag, TRUE, pServerMem, pClientMem);
}

NTSTATUS LpcPort::Refuse(LPC_MESSAGE_HEADER* pMsg)
{
	return _Accept(pMsg, NULL, FALSE);
};

NTSTATUS LpcPort::Reply(LPC_MESSAGE_HEADER* pMsg)
{
	ASSERT(m_hPort!=NULL);
	return NtReplyPort(m_hPort, pMsg);
}

NTSTATUS LpcPort::ReplyWaitReceivePort(LPC_MESSAGE_HEADER* pMsg, PVOID* pContext /*=NULL*/)
{
	ASSERT(m_hPort!=NULL);
	return NtReplyWaitReceivePort(m_hPort, pContext, NULL, pMsg);
}

DWORD LpcPort::Wait(DWORD dwMilliseconds)
{
	ASSERT(m_hPort!=NULL);
	if(m_bWaitable)
		return WaitForSingleObject(m_hPort, dwMilliseconds);
	else
		return 0;
}

BOOL LpcPort::IsWaitable() { return m_bWaitable; };

NTSTATUS LpcPort::RequestWaitReply(LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply)
{
	ASSERT(m_hPort!=NULL);
	return NtRequestWaitReplyPort(m_hPort, pRequest, pReply);
}

VOID LpcPort::Destroy()
{
	if(m_hPort)
	{
		CloseHandle(m_hPort);
		m_hPort = NULL;
	}
}

BOOL LpcPort::InitOwnerMemory(PLPC_SECTION_OWNER_MEMORY pOwnerMemory, DWORD dwSize)
{
	ASSERT(pOwnerMemory!=NULL);
	memset(pOwnerMemory, 0, sizeof(*pOwnerMemory));
	
	pOwnerMemory->SectionHandle = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, dwSize, NULL);
	if(pOwnerMemory->SectionHandle==NULL) return FALSE;
	pOwnerMemory->Length = sizeof(*pOwnerMemory);

	return TRUE;
}