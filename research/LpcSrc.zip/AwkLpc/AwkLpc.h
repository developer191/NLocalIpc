#pragma warning(push)
#pragma warning(disable:4005)
#include <ntstatus.h>
#pragma warning(pop)
#include "..\ntdll\lpc.h"

class LpcPort
{
public:
	LpcPort();
	~LpcPort();

	// Create a port
	NTSTATUS Create(LPCWSTR PortName, BOOL bWaitable, DWORD dwMaxMsgSize);

	// Wait for incoming messages (all)
	DWORD Wait(DWORD dwMilliseconds);
	NTSTATUS ReplyWaitReceivePort(LPC_MESSAGE_HEADER* pMsg, PVOID* pContext = NULL);

	// Accept a connection
	NTSTATUS Accept(LPC_MESSAGE_HEADER* pMsg, PVOID Tag, IN OUT PLPC_SECTION_OWNER_MEMORY pServerMem OPTIONAL = NULL, OUT PLPC_SECTION_MEMORY pClientMem OPTIONAL = NULL);
	
	// Refuse a connection
	NTSTATUS Refuse(LPC_MESSAGE_HEADER* pMsg);

	// Connect
	NTSTATUS Connect(LPCWSTR PortName, IN OUT PLPC_SECTION_OWNER_MEMORY pClientMem OPTIONAL = NULL, OUT PLPC_SECTION_MEMORY pServerMem OPTIONAL = NULL);

	// Send request and wait for reply (reply is mandatory)
	NTSTATUS RequestWaitReply(LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply);

	// Send a single reply
	NTSTATUS Reply(LPC_MESSAGE_HEADER* pMsg);

	// Destroy
	VOID Destroy();

	BOOL IsWaitable();

	static BOOL InitOwnerMemory(PLPC_SECTION_OWNER_MEMORY pOwnerMemory, DWORD dwSize);
protected:
	NTSTATUS _Accept(LPC_MESSAGE_HEADER* pMsg, PVOID Tag, BOOL bAccept, IN OUT PLPC_SECTION_OWNER_MEMORY pServerMem OPTIONAL = NULL, OUT PLPC_SECTION_MEMORY pClientMem OPTIONAL = NULL);
	PVOID m_Tag;
	BOOL m_bWaitable;
	HANDLE m_hPort;
};

class LpcClient
{
public:
	NTSTATUS Connect(LPCWSTR PortName, DWORD dwSectionSize = 0);
	NTSTATUS RequestWaitReply(LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply);
	VOID Close();

	const LPC_SECTION_OWNER_MEMORY& GetOwnMem();
	const LPC_SECTION_MEMORY& GetServerMem();
protected:
	LPC_SECTION_MEMORY m_ServerMem;
	LPC_SECTION_OWNER_MEMORY m_ClientMem;
	LpcPort m_Port;
};

class LpcReplyPort
{
public:
	NTSTATUS Accept(LPC_MESSAGE_HEADER* pMsg, PVOID UserPtr, PVOID Tag, DWORD dwSectionSize = 0);
	NTSTATUS Refuse(LPC_MESSAGE_HEADER* pMsg);
	NTSTATUS Reply(LPC_MESSAGE_HEADER* pMsg);
	PVOID GetUserPtr();
	VOID Close();

	const LPC_SECTION_OWNER_MEMORY& GetOwnMem();
	const LPC_SECTION_MEMORY& GetClientMem();
protected:
	LPC_SECTION_MEMORY m_ClientMem;
	LPC_SECTION_OWNER_MEMORY m_ServerMem;
	LpcPort m_Port;
	PVOID m_UserPtr;
};

class LpcServer
{
public:
	NTSTATUS Create(LPCWSTR PortName, BOOL bWaitable, DWORD dwMaxMsgSize, DWORD dwSectionSize = 0);
	NTSTATUS Run(LPC_MESSAGE_HEADER* pMsg, LPC_MESSAGE_HEADER* pMsgReply);
	VOID SetTimeout(DWORD dwMilliseconds);
	VOID Destroy();

	virtual NTSTATUS OnConnect(LPC_MESSAGE_HEADER* pRequest, BOOL* bAccept, PVOID* pUserPtr);
	virtual NTSTATUS OnRequest(LpcReplyPort& ReplyPort, LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply);
	virtual NTSTATUS OnClose(LpcReplyPort& ReplyPort);
	virtual NTSTATUS OnIdle();
protected:
	DWORD m_dwSectionSize;
	LpcPort m_Port;
	DWORD m_dwTimeout;
};