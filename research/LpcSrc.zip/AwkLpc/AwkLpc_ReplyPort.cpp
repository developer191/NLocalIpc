#include "AwkLpc_i.h"

NTSTATUS LpcReplyPort::Accept(LPC_MESSAGE_HEADER* pMsg, PVOID UserPtr, PVOID Tag, DWORD dwSectionSize)
{
	m_UserPtr = UserPtr;
	if(dwSectionSize != 0)
	{
		LpcPort::InitOwnerMemory(&m_ServerMem, dwSectionSize);
		memset(&m_ClientMem, 0, sizeof(m_ClientMem));
		m_ClientMem.Length = sizeof(m_ClientMem);
		return m_Port.Accept(pMsg, Tag, &m_ServerMem, &m_ClientMem);
	}
	else
	{
		memset(&m_ClientMem, 0, sizeof(m_ClientMem));
		memset(&m_ServerMem, 0, sizeof(m_ServerMem));
		return m_Port.Accept(pMsg, Tag);
	}
}

PVOID LpcReplyPort::GetUserPtr()
{
	return m_UserPtr;
};

NTSTATUS LpcReplyPort::Refuse(LPC_MESSAGE_HEADER* pMsg)
{
	return m_Port.Refuse(pMsg);
};

NTSTATUS LpcReplyPort::Reply(LPC_MESSAGE_HEADER* pMsg)
{
	return m_Port.Reply(pMsg);
}

VOID LpcReplyPort::Close()
{
	m_Port.Destroy();
}

const LPC_SECTION_OWNER_MEMORY& LpcReplyPort::GetOwnMem()
{
	return m_ServerMem;
};

const LPC_SECTION_MEMORY& LpcReplyPort::GetClientMem()
{
	return m_ClientMem;
};