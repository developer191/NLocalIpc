#include "AwkLpc_i.h"

NTSTATUS LpcClient::Connect(LPCWSTR PortName, DWORD dwSectionSize)
{
	if(dwSectionSize != 0)
	{
		LpcPort::InitOwnerMemory(&m_ClientMem, dwSectionSize);
		memset(&m_ServerMem, 0, sizeof(m_ServerMem));
		m_ServerMem.Length = sizeof(m_ServerMem);
		NTSTATUS NtStatus = m_Port.Connect(PortName, &m_ClientMem, &m_ServerMem);
		return NtStatus;
	}
	else
	{
		memset(&m_ClientMem, 0, sizeof(m_ClientMem));
		memset(&m_ServerMem, 0, sizeof(m_ServerMem));
		return m_Port.Connect(PortName);
	}
};

NTSTATUS LpcClient::RequestWaitReply(LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply)
{
	return m_Port.RequestWaitReply(pRequest, pReply);
};

VOID LpcClient::Close()
{
	m_Port.Destroy();
}

const LPC_SECTION_OWNER_MEMORY& LpcClient::GetOwnMem()
{
	return m_ClientMem;
};

const LPC_SECTION_MEMORY& LpcClient::GetServerMem()
{
	return m_ServerMem;
};