#include "AwkLpc_i.h"

NTSTATUS LpcServer::Create(LPCWSTR PortName, BOOL bWaitable, DWORD dwMaxMsgSize, DWORD dwSectionSize)
{
	m_dwSectionSize = dwSectionSize;
	return m_Port.Create(PortName, bWaitable, dwMaxMsgSize);
}

VOID LpcServer::SetTimeout(DWORD dwMilliseconds)
{
	ASSERT(m_Port.IsWaitable());
	m_dwTimeout = dwMilliseconds;
}

NTSTATUS LpcServer::Run(LPC_MESSAGE_HEADER* pMsg, LPC_MESSAGE_HEADER* pMsgReply)
{
	NTSTATUS NtStatus;
	while(true)
	{
		PVOID Context;
		if(m_Port.IsWaitable())
		{
_begin_wait:
			DWORD res = m_Port.Wait(m_dwTimeout);
			if(res == WAIT_TIMEOUT)
			{
				NtStatus = OnIdle();
				if(!NT_SUCCESS(NtStatus)) return NtStatus;
				goto _begin_wait;
			}
		}
		NtStatus = m_Port.ReplyWaitReceivePort(pMsg, &Context);
		if(!NT_SUCCESS(NtStatus))
		{
			return NtStatus;
		};

		LpcReplyPort* _Client = (LpcReplyPort*)Context;

		switch(pMsg->MessageType)
		{
		case LPC_CONNECTION_REQUEST:
			{
				PVOID UserPtr;
				BOOL bAccept;

				NtStatus = OnConnect(pMsg, &bAccept, &UserPtr);
				if(!NT_SUCCESS(NtStatus))
				{
					continue;
				}

				LpcReplyPort* _NewClient = new LpcReplyPort();
				if(_NewClient == NULL)
				{
					continue;
				}

				if(bAccept)
				{
					NtStatus = _NewClient->Accept(pMsg, UserPtr, _NewClient, m_dwSectionSize);
					if(!NT_SUCCESS(NtStatus))
					{
						continue;
					}
				}
				else
				{
					NtStatus = _NewClient->Refuse(pMsg);
					if(!NT_SUCCESS(NtStatus))
					{
						continue;
					}
				}

				Sleep(1); // it should be here, or client would not be able to connect

				break;
			}
		case LPC_REQUEST:
			{
				NtStatus = OnRequest(*_Client, pMsg, pMsgReply);
				if(!NT_SUCCESS(NtStatus))
				{
					continue;
				}

				NtStatus = _Client->Reply(pMsgReply);
				if(!NT_SUCCESS(NtStatus))
				{
					continue;
				};
				break;
			}
		case LPC_PORT_CLOSED:
			{
				OnClose(*_Client);
				delete _Client;
				break;
			}
		default:
			break;
		};
	};
};

void LpcServer::Destroy()
{
	m_Port.Destroy();
}

/*virtual*/ NTSTATUS LpcServer::OnConnect(LPC_MESSAGE_HEADER* pRequest, BOOL* bAccept, PVOID* pUserPtr)
{
	return STATUS_SUCCESS;
};

/*virtual*/ NTSTATUS LpcServer::OnRequest(LpcReplyPort& ReplyPort, LPC_MESSAGE_HEADER* pRequest, LPC_MESSAGE_HEADER* pReply)
{
	*pReply = *pRequest;
	return STATUS_SUCCESS;
};

/*virtual*/ NTSTATUS LpcServer::OnClose(LpcReplyPort& ReplyPort)
{
	return STATUS_SUCCESS;
};

/*virtual*/ NTSTATUS LpcServer::OnIdle()
{
	return STATUS_SUCCESS;
}