#pragma once
/*
http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/Port/
*/

extern "C"
{
#define UNUSED_MSG_TYPE        (0x0)
#define LPC_REQUEST            (0x1)
#define LPC_REPLY              (0x2)
#define LPC_DATAGRAM           (0x3)
#define LPC_LOST_REPLY         (0x4)
#define LPC_PORT_CLOSED        (0x5)
#define LPC_CLIENT_DIED        (0x6)
#define LPC_EXCEPTION          (0x7)
#define LPC_DEBUG_EVENT        (0x8)
#define LPC_ERROR_EVENT        (0x9)
#define LPC_CONNECTION_REQUEST (0xa)
#define LPC_CONNECTION_REFUSED (0xb)

	struct _OBJECT_ATTRIBUTES;
	typedef _OBJECT_ATTRIBUTES* POBJECT_ATTRIBUTES;

	typedef struct _LPC_MESSAGE_HEADER
	{
		USHORT                  DataLength;
		USHORT                  TotalLength;
		USHORT                  MessageType;
		USHORT                  DataInfoOffset;
		ULONG                   ProcessId;
		ULONG                   ThreadId;
		ULONG                   MessageId;
		ULONG                   CallbackId;
	} LPC_MESSAGE_HEADER, *PLPC_MESSAGE_HEADER;

	typedef struct _LPC_TERMINATION_MESSAGE
	{
		LPC_MESSAGE_HEADER      Header;
		LARGE_INTEGER           CreationTime;
	} LPC_TERMINATION_MESSAGE, *PLPC_TERMINATION_MESSAGE;

	typedef struct _LPC_SECTION_MEMORY
	{
		ULONG                   Length;
		ULONG                   ViewSize;
		PVOID                   ViewBase;
	} LPC_SECTION_MEMORY, *PLPC_SECTION_MEMORY;

	typedef struct _LPC_SECTION_OWNER_MEMORY
	{
		ULONG                   Length;
		HANDLE                  SectionHandle;
		ULONG                   OffsetInSection;
		ULONG                   ViewSize;
		PVOID                   ViewBase;
		PVOID                   OtherSideViewBase;
	} LPC_SECTION_OWNER_MEMORY, *PLPC_SECTION_OWNER_MEMORY;

	typedef enum _PORT_INFORMATION_CLASS
	{
		PortNoInformation
	} PORT_INFORMATION_CLASS, *PPORT_INFORMATION_CLASS;

	NTSYSAPI NTSTATUS NTAPI NtCreatePort(
		OUT PHANDLE              PortHandle,
		IN  POBJECT_ATTRIBUTES   ObjectAttributes,
		IN  ULONG                MaxConnectInfoLength,
		IN  ULONG                MaxDataLength,
		IN  ULONG                MaxPoolUsage
		);

	NTSYSAPI NTSTATUS NTAPI NtCreateWaitablePort(
		OUT PHANDLE              PortHandle,
		IN  POBJECT_ATTRIBUTES   ObjectAttributes,
		IN  ULONG                MaxConnectInfoLength,
		IN  ULONG                MaxDataLength,
		IN  ULONG                MaxPoolUsage
		);

	NTSYSAPI NTSTATUS NTAPI NtListenPort(
		IN  HANDLE               PortHandle,
		OUT PLPC_MESSAGE_HEADER  ConnectionRequest
		);

	NTSYSAPI NTSTATUS NTAPI NtAcceptConnectPort(
		OUT    PHANDLE                   ServerPortHandle,
		IN     PVOID                     PortContext,
		IN     PLPC_MESSAGE_HEADER       ConnectionMsg,
		IN     BOOLEAN                   AcceptConnection,
		IN OUT PLPC_SECTION_OWNER_MEMORY ServerSharedMemory           OPTIONAL,
		OUT    PLPC_SECTION_MEMORY       ClientSharedMemory           OPTIONAL
		);

	NTSYSAPI NTSTATUS NTAPI NtCompleteConnectPort(
		IN HANDLE               PortHandle
		);

	NTSYSAPI NTSTATUS NTAPI NtReplyWaitReceivePort(
		IN  HANDLE               PortHandle,
		OUT PVOID*               PortContext       OPTIONAL,
		IN  PLPC_MESSAGE_HEADER  Reply             OPTIONAL,
		OUT PLPC_MESSAGE_HEADER  IncomingRequest
		);

	NTSYSAPI NTSTATUS NTAPI NtReplyWaitReplyPort(
		IN     HANDLE               PortHandle,
		IN OUT PLPC_MESSAGE_HEADER  Reply
		);

	NTSYSAPI NTSTATUS NTAPI NtRequestPort(
		IN HANDLE               PortHandle,
		IN PLPC_MESSAGE_HEADER  Request
		);

	NTSYSAPI NTSTATUS NTAPI NtRequestWaitReplyPort(
		IN  HANDLE               PortHandle,
		IN  PLPC_MESSAGE_HEADER  Request,
		OUT PLPC_MESSAGE_HEADER  IncomingReply
		);

	NTSYSAPI NTSTATUS NTAPI NtWriteRequestData(
		IN  HANDLE               PortHandle,
		IN  PLPC_MESSAGE_HEADER  Request,
		IN  ULONG                DataIndex,
		IN  PVOID                Buffer,
		IN  ULONG                Length,
		OUT PULONG               ResultLength OPTIONAL
		);

	NTSYSAPI NTSTATUS NTAPI NtReadRequestData(
		IN  HANDLE               PortHandle,
		IN  PLPC_MESSAGE_HEADER  Request,
		IN  ULONG                DataIndex,
		OUT PVOID                Buffer,
		IN  ULONG                Length,
		OUT PULONG               ResultLength OPTIONAL
		);

	NTSYSAPI NTSTATUS NTAPI NtReplyPort(
		IN HANDLE               PortHandle,
		IN PLPC_MESSAGE_HEADER  Reply
		);

	NTSYSAPI NTSTATUS NTAPI NtQueryInformationPort(
		IN  HANDLE                 PortHandle,
		IN  PORT_INFORMATION_CLASS PortInformationClass,
		OUT PVOID                  PortInformation,
		IN  ULONG                  Length,
		OUT PULONG                 ResultLength OPTIONAL
		);

	NTSYSAPI NTSTATUS NTAPI NtImpersonateClientOfPort(
		IN HANDLE               PortHandle,
		IN PLPC_MESSAGE_HEADER  Request
		);

	NTSYSAPI NTSTATUS NTAPI NtConnectPort(
		OUT    PHANDLE                      ClientPortHandle,
		IN     PUNICODE_STRING              ServerPortName,
		IN     PSECURITY_QUALITY_OF_SERVICE SecurityQos,
		IN OUT PLPC_SECTION_OWNER_MEMORY    ClientSharedMemory   OPTIONAL,
		OUT    PLPC_SECTION_MEMORY          ServerSharedMemory   OPTIONAL,
		OUT    PULONG                       MaximumMessageLength OPTIONAL,
		IN OUT PVOID                        ConnectionInfo       OPTIONAL,
		IN OUT PULONG                       ConnectionInfoLength OPTIONAL
		);
}