#include <windows.h>
#include <ntsecapi.h>
#include <AwkLpc.h>

#include <conio.h>
#include <stdio.h>

#define NT_SUCCESS(x) ((x)>=0)

typedef struct _LPC_MESSAGE
{
	LPC_MESSAGE_HEADER      Hdr;
	BYTE                    Data[200];
} LPC_MESSAGE, *PLPC_MESSAGE;

int main()
{
	printf("Thread=%X Process=%X\n", GetCurrentThreadId(), GetCurrentProcessId());

	LpcClient client;

	NTSTATUS NtStatus = client.Connect(L"\\BaseNamedObjects\\PscSvcPort", 0x1000);
	if(!NT_SUCCESS(NtStatus))
	{
		printf("Connect() status=0x%X;\n", NtStatus);
		return -1;
	}

	unsigned int nMsg = 100000;
	unsigned int MsgLens[] = { 1, 4, 8, 32, 64, 128, 196 };
	for(int i=0;i<sizeof(MsgLens)/sizeof(MsgLens[0]);i++)
	{
		DWORD dw1 = GetTickCount();
		printf("Sending %u short messages (%u byte(s) each) and waiting for reply..\n", nMsg, MsgLens[i] );
		LPC_MESSAGE Msg;
		memset(&Msg,0,sizeof(Msg));
		Msg.Hdr.DataLength = MsgLens[i];
		Msg.Hdr.TotalLength = Msg.Hdr.DataLength + sizeof(Msg.Hdr);
		for(int j=0;j<Msg.Hdr.DataLength;j++) Msg.Data[i] = i%0xFF;

		PBYTE pOutMem = (PBYTE)client.GetOwnMem().ViewBase;
		if(pOutMem == NULL) { printf("pOutMem==NULL\n"); return -1; };
		*pOutMem = 0;

		for(unsigned int j=0;j<nMsg;j++)
		{
			(*pOutMem)++;
			LPC_MESSAGE MsgReply;

			NtStatus = client.RequestWaitReply(&Msg.Hdr, &MsgReply.Hdr);
			if(!NT_SUCCESS(NtStatus))
			{
				printf("RequestWaitReply() status=0x%X;\n", NtStatus);
				return -1;
			}

			PBYTE pInMem = (PBYTE)client.GetServerMem().ViewBase;
			BYTE v = *pInMem;
		}
		DWORD dw2 = GetTickCount();
		printf("%u ms elapsed;\n", dw2-dw1);
	}

	client.Close();

	printf("All OK, press any key.\n");
	getch();
	return 0;
}