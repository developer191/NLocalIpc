// Test__PipeServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE hPipe = CreateNamedPipe(_T("\\\\.\\pipe\\foopipe"), PIPE_ACCESS_DUPLEX, PIPE_TYPE_MESSAGE, PIPE_UNLIMITED_INSTANCES, 40960, 40960, NMPWAIT_USE_DEFAULT_WAIT, NULL);
	if(hPipe == INVALID_HANDLE_VALUE)
	{
		DWORD dwErr = GetLastError();
		cout << dwErr << endl;
		return 0;
	};

	BOOL bConnected = ConnectNamedPipe(hPipe, NULL);
	if(!bConnected)
	{
		DWORD dwErr = GetLastError();
		cout << dwErr << endl;
		return 0;
	};

	// echo
	for(;;)
	{
		TCHAR buf[4096];
		DWORD dw;
		ReadFile(hPipe, buf, 128, &dw, NULL);
		//printf("Msg\n");
		WriteFile(hPipe, buf, 128, &dw, NULL);
	}

	CloseHandle(hPipe);
	return 0;
}

