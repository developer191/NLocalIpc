// Test__PipeClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE hPipe = CreateFile( 
		_T("\\\\.\\pipe\\foopipe"),   // pipe name 
		GENERIC_READ |  // read and write access 
		GENERIC_WRITE, 
		0,              // no sharing 
		NULL,           // default security attributes
		OPEN_EXISTING,  // opens existing pipe 
		0,              // default attributes 
		NULL);          // no template file 

	if(hPipe == INVALID_HANDLE_VALUE)
	{
		DWORD dwErr = GetLastError();
		cout << dwErr << endl;
		return 0;
	}

	DWORD dw1 = GetTickCount();
	for(int i=0;i<100000;i++)
	{
		TCHAR buf[4096];
		DWORD dw;
		WriteFile(hPipe, buf, 128, &dw, NULL);
		ReadFile(hPipe, buf, 128, &dw, NULL);
		//printf("Got reply\n");
	}
	DWORD dw2 = GetTickCount();
	cout << "dw=" << (dw2-dw1) << "/100000" << endl;
	CloseHandle(hPipe);

	return 0;
}
