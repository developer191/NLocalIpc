// Test__SocketServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	SOCKET m_Server;
	u_short m_Port = 34567;
	WSADATA wsaData;
	sockaddr_in local;
	int wsaret=WSAStartup(0x101,&wsaData);
	if(wsaret!=0)
	{
		return 0;
	}
	local.sin_family=AF_INET;
	local.sin_addr.s_addr=INADDR_ANY;
	local.sin_port=htons((u_short)m_Port);
	m_Server=socket(AF_INET,SOCK_STREAM,0);
	if(m_Server==INVALID_SOCKET)
	{
		cout << "socket()" << endl;
		return 0;
	}
	if(bind(m_Server,(sockaddr*)&local,sizeof(local))!=0)
	{
		cout << "bind()" << endl;
		return 0;
	}
	if(listen(m_Server,10)!=0)
	{
		cout << "listen()" << endl;
		return 0;
	}

	SOCKET client;
	sockaddr_in from;
	int fromlen=sizeof(from);
	client=accept(m_Server, (struct sockaddr*)&from, &fromlen);

	char mbuf[130];
	int bufn = 0;
	while(true)
	{
		char tbuf[130];
		int r = recv(client, tbuf, 128, 0);
		if(r==0)
		{
			cout << "recv()" << endl;
			return 0;
		}
		//printf("r=%u\n",r);
		for(int i=0;i<r;i++)
		{
			if(bufn==128)
			{
				//printf("r");
				send(client, mbuf, 128, 0);
				bufn = 0;
			}
			else if(bufn > 128)
			{
				cout << "bufn>128" << endl;
				return 0;
			}
			else
			{
				mbuf[bufn] = tbuf[i];
				bufn++;
			}
		}
		if(bufn==128)
		{
			//printf("r");
			send(client, mbuf, 128, 0);
			bufn = 0;
		}
	}

	return 0;
}

