// Test__SocketClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	SOCKET m_Socket;
	u_short m_Port = 34567;
	char* host = "localhost";
	WSADATA wsaData;
	struct hostent *hp;
	unsigned int addr;
	struct sockaddr_in server;
	int wsaret=WSAStartup(0x101,&wsaData);
	if(wsaret) return false;
	m_Socket=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(m_Socket==INVALID_SOCKET)
		return false;
	if(inet_addr(host)==INADDR_NONE)
	{
		hp=gethostbyname(host);
	}
	else
	{
		addr=inet_addr(host);
		hp=gethostbyaddr((char*)&addr,sizeof(addr),AF_INET);
	}
	if(hp==NULL)
	{
		closesocket(m_Socket);
		return false;
	}
	server.sin_addr.s_addr=*((unsigned long*)hp->h_addr);
	server.sin_family=AF_INET;
	server.sin_port=htons(m_Port);
	if(connect(m_Socket,(struct sockaddr*)&server,sizeof(server)))
	{
		closesocket(m_Socket);
		return false;	
	}

	DWORD dw1 = GetTickCount();
	char mbuf[130];
	int bufn = 0;
	for(int i=0;i<100000;i++)
	{
		TCHAR buf[4096];
		send(m_Socket, buf, 128, 0);

		char tbuf[130];
		int r = recv(m_Socket, tbuf, 128, 0);
		if(r!=128)
		{
			cout << "recv()" << r << endl;
			return 0;
		}
	}
	DWORD dw2 = GetTickCount();
	cout << "dw=" << (dw2-dw1) << "/100000" << endl;


	return 0;
}